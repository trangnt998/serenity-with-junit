package webTest.phptravels.runner.signUp;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Screenshots;
import net.thucydides.core.annotations.Steps;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import webTest.phptravels.signUp.writeExcel;
import webTest.phptravels.steps.signUp.checkSignUpSteps;

@RunWith(SerenityRunner.class)
public class checkSignUpRunner {

    @Managed
    WebDriver driver;
    writeExcel write;

    public void setupDriver(){

        System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.setBinary("C:\\Program Files (x86)\\Viettel\\SFive\\Application\\sfive.exe");
        driver = new ChromeDriver(options);
    }

    @Steps
    checkSignUpSteps signup;

    @Screenshots(forEachAction = true)
    @Test
    public void checkSignUp() throws Exception {

        signup.setExcel();
        int row;



            int countError = 0;
            for (row = 18; row <=20 ; row++) {
                setupDriver();

                //result
                int Step1 = signup.signupDisplayIsOpened(driver, row);
                int Step2 = signup.userEnterFields(driver, row);
                int Step3 = signup.userClicksOnSignup(driver);
                int Step4 = signup.userIsNavigatedToProfile(driver, row);

                //driver.close();
                //driver.quit();
                int count = Step1 + Step2 + Step3 + Step4;
                System.out.println(Step1 +""+ Step2 +""+Step3+""+Step4);
                if (count != 4)
                    countError++;
                if ((Step1 == 1) && (Step2 == 1) && (Step3 == 1) && (Step4 == 1)) {
                    System.out.println("4");
                    write.putCellData(row, 16, "P");

                } else {
                    write.putCellData(row, 16, "F");

                }
            }
            if (countError != 0)
                Assert.assertEquals(0,countError);
        }

}
