package webTest.phptravels.steps.signUp;


import net.thucydides.core.annotations.Step;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import webTest.phptravels.signUp.readExcel;
import webTest.phptravels.signUp.writeExcel;

import java.io.IOException;

public class checkElementsSteps {
    readExcel read;
    writeExcel write;



    public void setExcel() throws Exception {
        //path excel file sheet read
        read.setExcelFileRead("src/test/resources/kbktAutoPhptravels.net.xlsx","SignUp");

        //create copy file excel
       // write.copyExcelFile("src/test/resources/kbktAutoPhptravels.net.xlsx","src/test/resources/2501_result_kbktAutoPhptravels.net.xlsx");

        //path excel file sheet write
        write.setExcelSheetWrite("src/test/resources/2502_result_kbktAutoPhptravels.net.xlsx", "SignUp");


    }

    //get error message
    public String getMessageError(WebDriver driver){
        WebElement error_message = null;
        String text = "";

        if(driver.findElements(By.xpath("//*[@id=\"headersignupform\"]/div[2]/div")).size() != 0){
            error_message = driver.findElement(By.xpath("//*[@id=\"name\"]"));
            text = error_message.getText();
            //System.out.println(text);
        }
        return text;
    }


    @Step("Signup display is opened")
    public int signupDisplayIsOpened(WebDriver driver) throws Exception {
        driver.get(read.getCellData(13,9));
        System.out.println("Link: "+ read.getCellData(13,9));

        String expectedUrl = read.getCellData(13,9);
        String actualUrl = driver.getCurrentUrl();
        if(expectedUrl.equals(actualUrl)){
            //System.out.println("Step Signup display is opened: "+ "true");
            return 1;
        }
        else {
            //System.out.println("Step Signup display is opened: "+ "false");
            return 0;
        }
    }

    //check First Name
    @Step("check First Name")
    public int checkFirstName(WebDriver driver) throws IOException {
        WebElement check = null;
        String text = "";

        if(driver.findElements(By.xpath(read.getCellData(13,3))).size() != 0){
            check = driver.findElement(By.xpath(read.getCellData(13,3)));
            text = check.getText();
            System.out.println("text: "+ text);
        }

        String expectedText = "First Name";
        String actualText = text;

        Assert.assertEquals(expectedText,actualText);
        if(expectedText.equals(actualText))
            return 1;
        else
            return 0;
    }


    //check LastName
    @Step("check Last Name")
    public int checkLastName(WebDriver driver) throws IOException {
        WebElement check = null;
        String text = "";

        if(driver.findElements(By.xpath(read.getCellData(13,4))).size() != 0){
            check = driver.findElement(By.xpath(read.getCellData(13,4)));
            text = check.getText();
            System.out.println("text: "+ text);
        }

        String expectedText = "Last Name";
        String actualText = text;

        Assert.assertEquals(expectedText,actualText);
        if (expectedText.equals(actualText))
            return 1;
        else
            return 0;
    }

    @Step("check Mobile Number")
    public int checkMobileNumber(WebDriver driver) throws IOException {
        WebElement check = null;
        String text = "";

        if(driver.findElements(By.xpath(read.getCellData(13,5))).size() != 0){
            check = driver.findElement(By.xpath(read.getCellData(13,5)));
            text = check.getText();
            System.out.println("text: "+ text);
        }

        String expectedText = "Mobile Number";
        String actualText = text;

        Assert.assertEquals(expectedText,actualText);
        if (expectedText.equals(actualText))
            return 1;
        else
            return 0;
    }

    @Step("check Email")
    public int checkEmail(WebDriver driver) throws IOException {
        WebElement check = null;
        String text = "";

        if(driver.findElements(By.xpath(read.getCellData(13,6))).size() != 0){
            check = driver.findElement(By.xpath(read.getCellData(13,6)));
            text = check.getText();
            System.out.println("text: "+ text);
        }

        String expectedText = "Email";
        String actualText = text;

        Assert.assertEquals(expectedText,actualText);
        if (expectedText.equals(actualText))
            return 1;
        else
            return 0;
    }

    @Step("check Password")
    public int checkPassword(WebDriver driver) throws IOException {
        WebElement check = null;
        String text = "";

        if(driver.findElements(By.xpath(read.getCellData(13,7))).size() != 0){
            check = driver.findElement(By.xpath(read.getCellData(13,7)));
            text = check.getText();
            System.out.println("text: "+ text);
        }

        String expectedText = "Password";
        String actualText = text;

        Assert.assertEquals(expectedText,actualText);
        if (expectedText.equals(actualText))
            return 1;
        else
            return 0;
    }
    @Step("check Confirm Password")
    public int checkConfirmPassword(WebDriver driver) throws IOException {
        WebElement check = null;
        String text = "";

        if(driver.findElements(By.xpath(read.getCellData(13,7))).size() != 0){
            check = driver.findElement(By.xpath(read.getCellData(13,8)));
            text = check.getText();
            System.out.println("text: "+ text);
        }

        String expectedText = "Confirm Password";
        String actualText = text;

        Assert.assertEquals(expectedText,actualText);
        if (expectedText.equals(actualText))
            return 1;
        else
            return 0;
    }
//xpath sign up //*[@id="headersignupform"]/div[8]

    @Step("check button Sign Up")
    public int checkButtonSignUp(WebDriver driver) throws IOException {
        WebElement check = null;
        String text = "";

        if(driver.findElements(By.xpath("//*[@id=\"headersignupform\"]/div[8]")).size() != 0){
            check = driver.findElement(By.xpath("//*[@id=\"headersignupform\"]/div[8]"));
            text = check.getText();
            System.out.println("text: "+ text);
        }

        String expectedText = "SIGN UP";
        String actualText = text;

        Assert.assertEquals(expectedText,actualText);
        if (expectedText.equals(actualText))
            return 1;
        else
            return 0;
    }

    @Step("check message error")
    public int checkMessageError(WebDriver driver) throws IOException {
        String expectedMsg = read.getCellData(13,11);
        String actualMsg = getMessageError(driver);
        Assert.assertEquals(expectedMsg,actualMsg);
        if(expectedMsg.equals(actualMsg))
            return 1;
        else
            return 0;
    }
/*

    //result
    public void result(WebDriver driver) throws Exception {
        int Step1 = signupDisplayIsOpened(driver);
        int Step2 = checkFirstName(driver);
        int Step3 = checkLastName(driver);
        int Step4 = checkMobileNumber(driver);
        int Step5 = checkEmail(driver);
        int Step6 = checkPassword(driver);
        int Step7 = checkConfirmPassword(driver);
        int Step8 = checkButtonSignUp(driver);
        int Step9 = checkMessageError(driver);

        if((Step1 == 1) &&(Step2 == 1)&&(Step3 == 1)&&(Step4 == 1)&&(Step5 == 1)&&(Step6 == 1)&&(Step7 == 1)&&(Step8 == 1)&&(Step9 == 1)){
            write.putCellData(12,13,"P");
            write.putCellData(12,16,"P");
        }
        else {
            write.putCellData(12,13,"F");
            write.putCellData(12,16,"F");
        }

    }

*/

}
