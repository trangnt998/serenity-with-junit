package webTest.phptravels.runner.signUp;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import webTest.phptravels.signUp.writeExcel;
import webTest.phptravels.steps.signUp.checkElementsSteps;

@RunWith(SerenityRunner.class)
public class checkElementsRunner {
    @Managed
    WebDriver driver;
    writeExcel write;

    public void setupDriver(){


        System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.setBinary("C:\\Program Files (x86)\\Viettel\\SFive\\Application\\sfive.exe");
        driver = new ChromeDriver(options);

    }

    @Steps
    checkElementsSteps elementSignup;

    @Test
    public void checkElementsSignup() throws Exception {
        setupDriver();
        elementSignup.setExcel();

        //result
            int Step1 = elementSignup.signupDisplayIsOpened(driver);
            int Step2 = elementSignup.checkFirstName(driver);
            int Step3 = elementSignup.checkLastName(driver);
            int Step4 = elementSignup.checkMobileNumber(driver);
            int Step5 = elementSignup.checkEmail(driver);
            int Step6 = elementSignup.checkPassword(driver);
            int Step7 = elementSignup.checkConfirmPassword(driver);
            int Step8 = elementSignup.checkButtonSignUp(driver);
            int Step9 = elementSignup.checkMessageError(driver);

            driver.close();

            driver.quit();

            if((Step1 == 1) &&(Step2 == 1)&&(Step3 == 1)&&(Step4 == 1)&&(Step5 == 1)&&(Step6 == 1)&&(Step7 == 1)&&(Step8 == 1)&&(Step9 == 1)){
                write.putCellData(13,13,"P");

            }
            else {
                write.putCellData(13,13,"F");

            }

        }

    }

