package webTest.phptravels.steps.signUp;

import net.thucydides.core.annotations.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import webTest.phptravels.signUp.readExcel;
import webTest.phptravels.signUp.writeExcel;

import java.io.IOException;

public class checkSignUpSteps {
    readExcel read;
    writeExcel write;

    public void setExcel() throws Exception {
        //path excel file sheet read
        read.setExcelFileRead("src/test/resources/2502_kbktAutoPhptravels.net.xlsx","SignUp");

        //create copy file excel
         write.copyExcelFile("src/test/resources/2502_kbktAutoPhptravels.net.xlsx",read.getCellData(2,7));

        //path excel file sheet write
        write.setExcelSheetWrite(read.getCellData(2,7), read.getCellData(2,8));
    }

    //get error message
    public String getMessageError(WebDriver driver, int row) throws IOException {
        WebElement error_message = null;
        String text = "";

        if(driver.findElements(By.xpath(read.getCellData(12,12))).size() != 0){
            error_message = driver.findElement(By.xpath(read.getCellData(row,12)));
            text = error_message.getText();
            //System.out.println(text);
        }
        return text;
    }

    @Step("Signup display is opened")
    public int signupDisplayIsOpened(WebDriver driver, int row) throws Exception {
        driver.get(read.getCellData(row,10));

        System.out.println("====Testcase: Row " + row +"=======================================================");
        System.out.println("Link: "+ read.getCellData(row,10));

        String expectedUrl = read.getCellData(row,10);
        String actualUrl = driver.getCurrentUrl();
        System.out.println("actualUrl: "+actualUrl);
        //Assert.assertEquals(expectedUrl,actualUrl);
        if(expectedUrl.equals(actualUrl))
            return 1;
        else
            return 0;
    }

// nhap du lieu tu excel
    @Step("User enter Fields")
    public int userEnterFields(WebDriver driver, int row) throws IOException {
        int fill = 0; //danh dau la 1 neu truong do ton tai, 0 neu khoong ton tai
            for (int i = 3; i <= 8; i++) {
                System.out.println("Data " + i +" "+read.getCellData(row,i));
                WebElement check = null;
                String text = "";

                //check su ton tai cua cac truong
                if (driver.findElements(By.xpath(read.getCellData(13, i))).size() != 0) {
                    check = driver.findElement(By.xpath(read.getCellData(13, i)));
                    text = check.getText();
                }
                String expectedText = read.getCellData(11, i);
                String actualText = text;

                // Assert.assertEquals(expectedText,actualText);
                if (expectedText.equals(actualText))
                    fill = 1;
                else {
                    fill = 0;
                    break;
                }
                driver.findElement(By.xpath(read.getCellData(12,i))).sendKeys(read.getCellData(row, i));
            }
        return fill;
    }

    @Step("user")
    public int userClicksOnSignup(WebDriver driver) throws InterruptedException, IOException {
        WebElement check = null;
        String text = "";

        if(driver.findElements(By.xpath(read.getCellData(12,9))).size() != 0){
            check = driver.findElement(By.xpath(read.getCellData(12,9)));
            text = check.getText();
        }
        String expectedText = read.getCellData(11,9);
        String actualText = text;

        //Assert.assertEquals(expectedText,actualText);

        WebElement sign = driver.findElement(By.xpath(read.getCellData(12,9)));
        sign.click();
        Thread.sleep(2000);

        if (expectedText.equals(actualText))
            return 1;
        else
            return 0;
    }

    @Step("User is navigated to profile")
    public int userIsNavigatedToProfile(WebDriver driver, int row) throws IOException {
        String actualMsg = getMessageError(driver, row);
        String expectedMsg = read.getCellData(row,14);
        System.out.println("acmsg: " + actualMsg);
        System.out.println("exmsg: "+expectedMsg);
        String actualUrl = driver.getCurrentUrl();
        String expectedUrl = read.getCellData(row,11);

        //Assert.assertEquals(expectedUrl, actualUrl);
        if (expectedUrl.equals(actualUrl) && expectedMsg.equals(actualMsg))
            return 1;
        else
            return 0;
    }
/*//Nhap tung testcase

    @Step("User enter Fields")
    public int userEnterFields(WebDriver driver) throws IOException {
        int fill = 1; //danh dau la 1 neu truong do ton tai, 0 neu khoong ton tai

        driver.findElement(By.name("firstname")).sendKeys(read.getCellData(14, 3));
        driver.findElement(By.xpath(read.getCellData(13,4))).sendKeys(read.getCellData(14, 4));
        driver.findElement(By.xpath(read.getCellData(13,5))).sendKeys(read.getCellData(14, 5));
        driver.findElement(By.xpath(read.getCellData(13,6))).sendKeys(read.getCellData(14, 6));
        driver.findElement(By.xpath(read.getCellData(13,7))).sendKeys(read.getCellData(14, 7));
        driver.findElement(By.xpath(read.getCellData(13,8))).sendKeys(read.getCellData(14, 8));
        return fill;

    }*/
}
