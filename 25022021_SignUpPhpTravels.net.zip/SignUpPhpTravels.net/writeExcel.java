package webTest.phptravels.signUp;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;

public class writeExcel {
    private static XSSFSheet ExcelWSheet;
    private static XSSFWorkbook ExcelWBook;
    private static XSSFCell Cell;
    private static XSSFRow Row;
    public static int rowcount;
    private static readExcel read;

    //cach 3
    public static void copyExcelFile(String input, String output) throws IOException {

        //create file excel copy in java7
        File src = new File(input);
        File dest = new File(output);
        Files.copy(src.toPath(),dest.toPath());

    }
    public static void setExcelSheetWrite(String Pathin, String SheetName) throws IOException {
        try {
            //file input to Copy data from scenario file to result file,
            //vi moi vong lap, no tao file moi thi se chi luu ket qua cuoi nen de duong dan file out neu dung vong lap trong chuong trinh chinh
            FileInputStream ExcelFile = new FileInputStream(Pathin);

            ExcelWBook = new XSSFWorkbook(ExcelFile);
            ExcelWSheet = ExcelWBook.getSheet(SheetName);

            //rowcount = ExcelWSheet.getLastRowNum() + 1; //the number of row
            //System.out.println("total rows is: " + rowcount);
        } catch (Exception e) {
            throw (e);
        }
    }

    public static void putCellData(int RowNum, int ColNum, String value) throws IOException {
        Cell = ExcelWSheet.getRow(RowNum).createCell(ColNum);
        Cell.setCellValue(value);

        //File out = new File("src/test/resources/2502_result_kbktAutoPhptravels.net(1).xlsx");
        //chu y: set cung duong dan voi setExcelSheetWrite...
        File out = new File(read.getCellData(2,7));

        FileOutputStream fout = new FileOutputStream(out);
        ExcelWBook.write(fout);
        //ExcelWBook.close();

    }
}





