package webTest.phptravels.signUp;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;

public class readExcel {

    private static XSSFSheet ExcelWSheet;
    private static XSSFWorkbook ExcelWBook;
    private static XSSFCell Cell;
    private static XSSFRow Row;
    public static int rowcount;
    public static void setExcelFileRead(String Path, String SheetName) throws Exception {
        try {
            // Open the Excel file
            FileInputStream ExcelFile = new FileInputStream(Path);
            // Access the required test data sheet
            ExcelWBook = new XSSFWorkbook(ExcelFile);
            ExcelWSheet = ExcelWBook.getSheet(SheetName);

            //System.out.println("total rows is: " + config.getCellData(1,1));
            //Sheet need to read
            XSSFSheet Sheetname = ExcelWBook.getSheet(SheetName);

            //rowcount = Sheetname.getLastRowNum() + 1; //the number of row
        } catch (Exception e) {
            throw (e);
        }
    }

    public static String getCellData(int RowNum, int ColNum) throws IOException {
        try {
            Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);

            CellType cellType = Cell.getCellType();
            Object cellValue = null;

            switch (cellType){
                case BOOLEAN:
                    cellValue = Cell.getBooleanCellValue();
                    break;
                case FORMULA:
                    Workbook workbook = Cell.getSheet().getWorkbook();
                    FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
                    cellValue = evaluator.evaluate(Cell).getNumberValue();
                    break;
                case NUMERIC:
                    cellValue = Cell.getNumericCellValue();
                    break;
                case STRING:
                    cellValue = Cell.getStringCellValue();
                    break;
                case _NONE:
                case BLANK:
                case ERROR:
                    break;
                default:
                    break;
            }



            return (String) cellValue;
        } catch (Exception e) {
            return "";
        }
    }


}
